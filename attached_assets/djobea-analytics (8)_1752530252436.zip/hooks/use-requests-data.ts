"use client"

import { useState, useEffect, useCallback } from "react"
import { apiClient } from "@/lib/api-client"
import { useToast } from "@/hooks/use-toast"
import { logger } from "@/lib/logger"

export interface RequestsFilters {
  search: string
  status: string
  priority: string
  serviceType: string
  location: string
  dateRange: string
}

export function useRequestsData(filters: RequestsFilters, page: number, pageSize: number) {
  const [data, setData] = useState<any[]>([])
  const [stats, setStats] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [pagination, setPagination] = useState<any>({
    page: 1,
    totalPages: 1,
    total: 0,
  })
  const { toast } = useToast()

  const fetchData = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)

      const params = {
        page,
        limit: pageSize,
        search: filters.search || undefined,
        status: filters.status || undefined,
        priority: filters.priority || undefined,
        serviceType: filters.serviceType || undefined,
        location: filters.location || undefined,
        dateRange: filters.dateRange || undefined,
      }

      const result = await apiClient.getRequests(params)

      if (result.success) {
        setData(result.data?.data || [])
        setStats(result.data?.stats || null)
        setPagination(result.data?.pagination || {})
      } else {
        throw new Error(result.error || "Failed to fetch requests")
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Erreur lors du chargement des demandes"
      setError(message)
      logger.error("Failed to fetch requests", { error: err, filters, page, pageSize })

      toast({
        title: "Erreur",
        description: message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }, [filters, page, pageSize, toast])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  const refetch = useCallback(() => {
    fetchData()
  }, [fetchData])

  const createRequest = useCallback(
    async (requestData: any) => {
      try {
        setLoading(true)
        const result = await apiClient.createRequest(requestData)

        if (result.success) {
          await fetchData()
          toast({
            title: "Succès",
            description: "Demande créée avec succès",
            variant: "default",
          })
        } else {
          throw new Error(result.error || "Failed to create request")
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : "Erreur lors de la création"
        logger.error("Failed to create request", { error: err, requestData })

        toast({
          title: "Erreur",
          description: message,
          variant: "destructive",
        })
        throw err
      } finally {
        setLoading(false)
      }
    },
    [fetchData, toast],
  )

  const updateRequest = useCallback(
    async (id: string, updates: any) => {
      try {
        setLoading(true)
        const result = await apiClient.updateRequest(id, updates)

        if (result.success) {
          await fetchData()
          toast({
            title: "Succès",
            description: "Demande mise à jour avec succès",
            variant: "default",
          })
        } else {
          throw new Error(result.error || "Failed to update request")
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : "Erreur lors de la mise à jour"
        logger.error("Failed to update request", { error: err, id, updates })

        toast({
          title: "Erreur",
          description: message,
          variant: "destructive",
        })
        throw err
      } finally {
        setLoading(false)
      }
    },
    [fetchData, toast],
  )

  const assignRequest = useCallback(
    async (id: string, providerId: string) => {
      try {
        const result = await apiClient.assignRequest(id, providerId)

        if (result.success) {
          await fetchData()
          toast({
            title: "Succès",
            description: "Demande assignée avec succès",
            variant: "default",
          })
        } else {
          throw new Error(result.error || "Failed to assign request")
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : "Erreur lors de l'assignation"
        logger.error("Failed to assign request", { error: err, id, providerId })

        toast({
          title: "Erreur",
          description: message,
          variant: "destructive",
        })
        throw err
      }
    },
    [fetchData, toast],
  )

  return {
    data,
    stats,
    pagination,
    loading,
    error,
    refetch,
    createRequest,
    updateRequest,
    assignRequest,
  }
}
