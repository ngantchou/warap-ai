"use client"

import { useState, useEffect, useCallback } from "react"
import { apiClient } from "@/lib/api-client"
import { useToast } from "@/hooks/use-toast"
import { logger } from "@/lib/logger"

export interface ProvidersFilters {
  search: string
  status: string
  specialty: string
  zone: string
  minRating: string
  sortBy?: "name" | "rating" | "missions" | "joinDate"
  sortOrder?: "asc" | "desc"
}

export interface ProvidersPagination {
  page: number
  totalPages: number
  total: number
  startIndex: number
  endIndex: number
  hasNextPage: boolean
  hasPrevPage: boolean
}

export interface ProvidersStats {
  total: number
  active: number
  inactive: number
  suspended: number
  available: number
  avgRating: number
  newThisMonth: number
  topPerformers: any[]
}

export function useProvidersData(filters: ProvidersFilters, page: number, pageSize: number) {
  const [data, setData] = useState<any[]>([])
  const [stats, setStats] = useState<ProvidersStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [pagination, setPagination] = useState<ProvidersPagination>({
    page: 1,
    totalPages: 1,
    total: 0,
    startIndex: 0,
    endIndex: 0,
    hasNextPage: false,
    hasPrevPage: false,
  })
  const { toast } = useToast()

  const fetchData = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)

      const params = {
        page,
        limit: pageSize,
        search: filters.search || undefined,
        status: filters.status || undefined,
        service: filters.specialty || undefined,
        location: filters.zone || undefined,
        rating: filters.minRating ? Number.parseFloat(filters.minRating) : undefined,
      }

      const result = await apiClient.getProviders(params)

      if (result.success) {
        setData(result.data?.providers || [])
        setStats(result.data?.stats || null)

        // Calculate pagination from API response
        const apiPagination = result.data?.pagination || {}
        const calculatedPagination: ProvidersPagination = {
          page: apiPagination.page || page,
          totalPages: apiPagination.totalPages || 1,
          total: apiPagination.total || 0,
          startIndex: ((apiPagination.page || page) - 1) * pageSize + 1,
          endIndex: Math.min((apiPagination.page || page) * pageSize, apiPagination.total || 0),
          hasNextPage: apiPagination.hasNext || false,
          hasPrevPage: apiPagination.hasPrev || false,
        }

        setPagination(calculatedPagination)
      } else {
        throw new Error(result.error || "Failed to fetch providers")
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Erreur lors du chargement des données"
      setError(message)
      logger.error("Failed to fetch providers", { error: err, filters, page, pageSize })

      toast({
        title: "Erreur",
        description: message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }, [filters, page, pageSize, toast])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  const refetch = useCallback(() => {
    fetchData()
  }, [fetchData])

  const createProvider = useCallback(
    async (providerData: any) => {
      try {
        setLoading(true)
        const result = await apiClient.createProvider(providerData)

        if (result.success) {
          await fetchData() // Refresh data after creation
          toast({
            title: "Succès",
            description: "Prestataire créé avec succès",
            variant: "default",
          })
        } else {
          throw new Error(result.error || "Failed to create provider")
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : "Erreur lors de la création"
        logger.error("Failed to create provider", { error: err, providerData })

        toast({
          title: "Erreur",
          description: message,
          variant: "destructive",
        })
        throw err
      } finally {
        setLoading(false)
      }
    },
    [fetchData, toast],
  )

  const updateProvider = useCallback(
    async (id: string, updates: any) => {
      try {
        setLoading(true)
        const result = await apiClient.updateProvider(id, updates)

        if (result.success) {
          await fetchData() // Refresh data after update
          toast({
            title: "Succès",
            description: "Prestataire mis à jour avec succès",
            variant: "default",
          })
        } else {
          throw new Error(result.error || "Failed to update provider")
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : "Erreur lors de la mise à jour"
        logger.error("Failed to update provider", { error: err, id, updates })

        toast({
          title: "Erreur",
          description: message,
          variant: "destructive",
        })
        throw err
      } finally {
        setLoading(false)
      }
    },
    [fetchData, toast],
  )

  const deleteProvider = useCallback(
    async (id: string) => {
      try {
        setLoading(true)
        const result = await apiClient.deleteProvider(id)

        if (result.success) {
          await fetchData() // Refresh data after deletion
          toast({
            title: "Succès",
            description: "Prestataire supprimé avec succès",
            variant: "default",
          })
        } else {
          throw new Error(result.error || "Failed to delete provider")
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : "Erreur lors de la suppression"
        logger.error("Failed to delete provider", { error: err, id })

        toast({
          title: "Erreur",
          description: message,
          variant: "destructive",
        })
        throw err
      } finally {
        setLoading(false)
      }
    },
    [fetchData, toast],
  )

  const updateProviderStatus = useCallback(
    async (id: string, status: string) => {
      try {
        const result = await apiClient.updateProviderStatus(id, status)

        if (result.success) {
          await fetchData() // Refresh data after status update
          toast({
            title: "Succès",
            description: `Statut du prestataire mis à jour: ${status}`,
            variant: "default",
          })
        } else {
          throw new Error(result.error || "Failed to update provider status")
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : "Erreur lors de la mise à jour du statut"
        logger.error("Failed to update provider status", { error: err, id, status })

        toast({
          title: "Erreur",
          description: message,
          variant: "destructive",
        })
        throw err
      }
    },
    [fetchData, toast],
  )

  return {
    data,
    stats,
    pagination,
    loading,
    error,
    refetch,
    createProvider,
    updateProvider,
    deleteProvider,
    updateProviderStatus,
  }
}
