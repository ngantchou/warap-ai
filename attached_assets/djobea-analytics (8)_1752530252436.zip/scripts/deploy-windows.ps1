# ============================================================================
# Djobea Analytics - Frontend Deployment Script for Windows
# ============================================================================
# Description: Deploy frontend-only application that connects to backend APIs
# Version: 2.0.0
# ============================================================================

param(
    [Parameter(Position=0)]
    [ValidateSet("dev", "prod", "build", "setup", "clean", "logs", "status", "help")]
    [string]$Action = "dev",
    
    [Parameter()]
    [switch]$Force,
    
    [Parameter()]
    [switch]$SkipChecks,
    
    [Parameter()]
    [switch]$Verbose
)

# Script configuration
$ErrorActionPreference = "Stop"
if ($Verbose) { $VerbosePreference = "Continue" }

# Color output functions
function Write-ColorOutput {
    param([string]$Message, [string]$Color = "White")
    $colors = @{
        "Red" = [ConsoleColor]::Red; "Green" = [ConsoleColor]::Green
        "Yellow" = [ConsoleColor]::Yellow; "Blue" = [ConsoleColor]::Blue
        "Cyan" = [ConsoleColor]::Cyan; "Magenta" = [ConsoleColor]::Magenta
        "White" = [ConsoleColor]::White
    }
    Write-Host $Message -ForegroundColor $colors[$Color]
}

function Write-Success { param([string]$Message) Write-ColorOutput "✅ $Message" "Green" }
function Write-Error { param([string]$Message) Write-ColorOutput "❌ $Message" "Red" }
function Write-Warning { param([string]$Message) Write-ColorOutput "⚠️  $Message" "Yellow" }
function Write-Info { param([string]$Message) Write-ColorOutput "ℹ️  $Message" "Blue" }
function Write-Header { 
    param([string]$Message)
    Write-Host ""
    Write-ColorOutput "🚀 $Message" "Cyan"
    Write-ColorOutput ("=" * ($Message.Length + 4)) "Cyan"
}

# Check prerequisites for frontend deployment
function Test-Prerequisites {
    Write-Header "Checking Prerequisites for Frontend Deployment"
    
    $prerequisites = @()
    
    # Check Docker
    try {
        $dockerVersion = docker --version 2>$null
        if ($dockerVersion) {
            Write-Success "Docker: $dockerVersion"
        } else {
            throw "Docker not found"
        }
    } catch {
        Write-Error "Docker is required for containerized deployment"
        $prerequisites += "Docker Desktop"
    }
    
    # Check Docker Compose
    try {
        $composeVersion = docker-compose --version 2>$null
        if ($composeVersion) {
            Write-Success "Docker Compose: $composeVersion"
        } else {
            throw "Docker Compose not found"
        }
    } catch {
        Write-Error "Docker Compose is required"
        $prerequisites += "Docker Compose"
    }
    
    # Check Node.js (optional for local development)
    try {
        $nodeVersion = node --version 2>$null
        if ($nodeVersion) {
            Write-Success "Node.js: $nodeVersion (for local development)"
        }
    } catch {
        Write-Info "Node.js not found (optional for Docker-only deployment)"
    }
    
    # Check pnpm (optional)
    try {
        $pnpmVersion = pnpm --version 2>$null
        if ($pnpmVersion) {
            Write-Success "pnpm: v$pnpmVersion"
        }
    } catch {
        Write-Info "pnpm not found (will use npm in Docker)"
    }
    
    if ($prerequisites.Count -gt 0 -and -not $SkipChecks) {
        Write-Error "Missing prerequisites: $($prerequisites -join ', ')"
        Write-Info "Run: .\scripts\setup-windows.ps1 -All"
        exit 1
    }
    
    # Test Docker daemon
    try {
        docker info | Out-Null
        Write-Success "Docker daemon is running"
    } catch {
        Write-Error "Docker daemon is not running. Please start Docker Desktop."
        exit 1
    }
}

# Setup frontend environment
function Initialize-FrontendEnvironment {
    Write-Header "Setting up Frontend Environment"
    
    # Create necessary directories
    $directories = @("logs", "uploads", "public/exports")
    foreach ($dir in $directories) {
        if (-not (Test-Path $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
            Write-Info "Created directory: $dir"
        }
    }
    
    # Setup .env.local for development
    if (-not (Test-Path ".env.local")) {
        $envContent = @"
# Djobea Analytics - Frontend Environment Configuration
# This frontend connects to backend APIs

# Application URLs
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_API_URL=http://djobea.ai/api
NEXT_PUBLIC_WS_URL=ws://djobea.ai/ws
NEXT_PUBLIC_WS_PORT=443

# External APIs
NEXT_PUBLIC_GOOGLE_MAPS_API_KEY=your-google-maps-api-key
NEXT_PUBLIC_MAPBOX_ACCESS_TOKEN=your-mapbox-access-token

# Feature Flags
NEXT_PUBLIC_ENABLE_AI_PREDICTIONS=true
NEXT_PUBLIC_ENABLE_GEOLOCATION=true
NEXT_PUBLIC_ENABLE_REALTIME=true
NEXT_PUBLIC_ENABLE_WHATSAPP=true
NEXT_PUBLIC_ENABLE_ANALYTICS_EXPORT=true

# Push Notifications
NEXT_PUBLIC_VAPID_PUBLIC_KEY=your-vapid-public-key

# Analytics & Monitoring
NEXT_PUBLIC_GOOGLE_ANALYTICS_ID=G-XXXXXXXXXX
NEXT_PUBLIC_MIXPANEL_TOKEN=your-mixpanel-token
NEXT_PUBLIC_HOTJAR_ID=your-hotjar-id

# Development Settings
NODE_ENV=development
NEXT_TELEMETRY_DISABLED=1

# Custom Configuration
CUSTOM_KEY=your-custom-value
"@
        $envContent | Out-File -FilePath ".env.local" -Encoding UTF8
        Write-Success "Created .env.local for frontend configuration"
        Write-Warning "Please update API URLs and keys in .env.local"
    } else {
        Write-Info ".env.local already exists"
    }
    
    # Setup .env.production for production
    if ($Action -eq "prod" -and -not (Test-Path ".env.production")) {
        $prodEnvContent = @"
# Djobea Analytics - Production Frontend Configuration

# Application URLs (UPDATE THESE!)
NEXT_PUBLIC_APP_URL=https://analytics.djobea.ai
NEXT_PUBLIC_API_URL=https://api.djobea.ai/api
NEXT_PUBLIC_WS_URL=wss://api.djobea.ai/ws
NEXT_PUBLIC_WS_PORT=443

# External APIs (UPDATE THESE!)
NEXT_PUBLIC_GOOGLE_MAPS_API_KEY=your-production-google-maps-api-key
NEXT_PUBLIC_MAPBOX_ACCESS_TOKEN=your-production-mapbox-access-token

# Feature Flags
NEXT_PUBLIC_ENABLE_AI_PREDICTIONS=true
NEXT_PUBLIC_ENABLE_GEOLOCATION=true
NEXT_PUBLIC_ENABLE_REALTIME=true
NEXT_PUBLIC_ENABLE_WHATSAPP=true
NEXT_PUBLIC_ENABLE_ANALYTICS_EXPORT=true

# Push Notifications (UPDATE THIS!)
NEXT_PUBLIC_VAPID_PUBLIC_KEY=your-production-vapid-public-key

# Analytics & Monitoring (UPDATE THESE!)
NEXT_PUBLIC_GOOGLE_ANALYTICS_ID=G-XXXXXXXXXX
NEXT_PUBLIC_MIXPANEL_TOKEN=your-production-mixpanel-token
NEXT_PUBLIC_HOTJAR_ID=your-production-hotjar-id

# Production Settings
NODE_ENV=production
NEXT_TELEMETRY_DISABLED=1

# Custom Configuration
CUSTOM_KEY=your-production-custom-value
"@
        $prodEnvContent | Out-File -FilePath ".env.production" -Encoding UTF8
        Write-Success "Created .env.production template"
        Write-Warning "Please update all production URLs and API keys!"
    }
}

# Build frontend Docker images
function Build-FrontendImages {
    param([string]$Environment = "dev")
    
    Write-Header "Building Frontend Docker Images for $Environment"
    
    try {
        if ($Environment -eq "dev") {
            Write-Info "Building development image..."
            docker-compose -f docker-compose.dev.yml build --no-cache
        } else {
            Write-Info "Building production image..."
            docker-compose -f docker-compose.prod.yml build --no-cache
        }
        Write-Success "Frontend images built successfully"
    } catch {
        Write-Error "Failed to build frontend images: $_"
        exit 1
    }
}

# Start frontend services
function Start-FrontendServices {
    param([string]$Environment = "dev")
    
    Write-Header "Starting Frontend Services for $Environment"
    
    try {
        # Stop any existing containers
        docker-compose -f docker-compose.dev.yml down 2>$null
        docker-compose -f docker-compose.prod.yml down 2>$null
        
        if ($Environment -eq "dev") {
            docker-compose -f docker-compose.dev.yml up -d
        } else {
            docker-compose -f docker-compose.prod.yml up -d
        }
        
        Write-Success "Frontend services started successfully"
        
        # Wait for services to be ready
        Write-Info "Waiting for frontend to be ready..."
        Start-Sleep -Seconds 15
        Test-FrontendHealth
        
    } catch {
        Write-Error "Failed to start frontend services: $_"
        exit 1
    }
}

# Test frontend health
function Test-FrontendHealth {
    Write-Header "Checking Frontend Health"
    
    $frontendUrl = "http://localhost:3000"
    $maxAttempts = 30
    $attempt = 0
    
    Write-Info "Testing frontend at $frontendUrl..."
    
    do {
        $attempt++
        try {
            $response = Invoke-WebRequest -Uri $frontendUrl -TimeoutSec 5 -UseBasicParsing
            if ($response.StatusCode -eq 200) {
                Write-Success "Frontend is healthy and accessible"
                return $true
            }
        } catch {
            if ($attempt -eq $maxAttempts) {
                Write-Error "Frontend health check failed after $maxAttempts attempts"
                return $false
            }
            Write-Host "." -NoNewline
            Start-Sleep -Seconds 2
        }
    } while ($attempt -lt $maxAttempts)
    
    return $false
}

# Show frontend logs
function Show-FrontendLogs {
    Write-Header "Frontend Application Logs"
    
    try {
        docker-compose -f docker-compose.dev.yml logs -f djobea-frontend
    } catch {
        Write-Error "Failed to show logs: $_"
    }
}

# Show frontend status
function Show-FrontendStatus {
    Write-Header "Frontend Service Status"
    
    try {
        Write-Info "Container Status:"
        docker-compose -f docker-compose.dev.yml ps
        
        Write-Host ""
        Write-Info "Resource Usage:"
        docker stats --no-stream --format "table {{.Container}}\t{{.CPUPerc}}\t{{.MemUsage}}\t{{.NetIO}}"
        
        Write-Host ""
        Write-Info "Frontend URLs:"
        Write-Success "Application: http://localhost:3000"
        Write-Success "Health Check: http://localhost:3000/api/health"
        
    } catch {
        Write-Error "Failed to show status: $_"
    }
}

# Clean frontend resources
function Clear-FrontendResources {
    Write-Header "Cleaning Frontend Docker Resources"
    
    if ($Force -or (Read-Host "Remove all frontend containers and images? (y/N)") -eq "y") {
        try {
            # Stop containers
            docker-compose -f docker-compose.dev.yml down -v --remove-orphans 2>$null
            docker-compose -f docker-compose.prod.yml down -v --remove-orphans 2>$null
            
            # Remove frontend images
            docker images "djobea-analytics*" -q | ForEach-Object { docker rmi $_ -f 2>$null }
            
            # Clean unused resources
            docker system prune -f
            
            Write-Success "Frontend resources cleaned successfully"
        } catch {
            Write-Error "Failed to clean resources: $_"
        }
    } else {
        Write-Info "Cleanup cancelled"
    }
}

# Show help
function Show-Help {
    Write-Host ""
    Write-ColorOutput "Djobea Analytics - Frontend Deployment Script" -Color "Cyan"
    Write-Host "=" * 50
    Write-Host ""
    Write-Host "Usage: .\scripts\deploy-windows.ps1 [ACTION] [OPTIONS]" -ForegroundColor White
    Write-Host ""
    Write-Host "Actions:" -ForegroundColor Yellow
    Write-Host "  dev          Start development environment" -ForegroundColor White
    Write-Host "  prod         Start production environment" -ForegroundColor White
    Write-Host "  build        Build Docker images only" -ForegroundColor White
    Write-Host "  setup        Setup environment files only" -ForegroundColor White
    Write-Host "  clean        Clean Docker resources" -ForegroundColor White
    Write-Host "  logs         Show application logs" -ForegroundColor White
    Write-Host "  status       Show service status" -ForegroundColor White
    Write-Host "  help         Show this help" -ForegroundColor White
    Write-Host ""
    Write-Host "Options:" -ForegroundColor Yellow
    Write-Host "  -Force       Force actions without confirmation" -ForegroundColor White
    Write-Host "  -SkipChecks  Skip prerequisite checks" -ForegroundColor White
    Write-Host "  -Verbose     Enable verbose output" -ForegroundColor White
    Write-Host ""
    Write-Host "Examples:" -ForegroundColor Yellow
    Write-Host "  .\scripts\deploy-windows.ps1 dev" -ForegroundColor Green
    Write-Host "  .\scripts\deploy-windows.ps1 prod -Force" -ForegroundColor Green
    Write-Host "  .\scripts\deploy-windows.ps1 build" -ForegroundColor Green
    Write-Host ""
    Write-Host "Note: This deploys the frontend only. Backend APIs must be running separately." -ForegroundColor Yellow
    Write-Host ""
}

# Main execution
function Main {
    Write-Header "Djobea Analytics - Frontend Deployment (Windows)"
    Write-Info "Action: $Action"
    Write-Info "This is a frontend-only deployment that connects to backend APIs"
    Write-Host ""
    
    # Check if we're in the right directory
    if (-not (Test-Path "package.json")) {
        Write-Error "package.json not found. Run from project root directory."
        exit 1
    }
    
    switch ($Action.ToLower()) {
        "setup" {
            Initialize-FrontendEnvironment
            Write-Success "Frontend environment setup completed!"
            Write-Info "Next: Update .env.local with your backend API URLs"
        }
        
        "dev" {
            if (-not $SkipChecks) { Test-Prerequisites }
            Initialize-FrontendEnvironment
            Build-FrontendImages -Environment "dev"
            Start-FrontendServices -Environment "dev"
            
            Write-Success "🎉 Development frontend is ready!"
            Write-Info "🌐 Application: http://localhost:3000"
            Write-Info "📊 Logs: .\scripts\deploy-windows.ps1 logs"
            Write-Info "🛑 Stop: docker-compose -f docker-compose.dev.yml down"
            Write-Warning "⚠️  Make sure your backend APIs are running!"
        }
        
        "prod" {
            if (-not $SkipChecks) { Test-Prerequisites }
            Initialize-FrontendEnvironment
            Build-FrontendImages -Environment "prod"
            Start-FrontendServices -Environment "prod"
            
            Write-Success "🎉 Production frontend is ready!"
            Write-Info "🌐 Application: http://localhost:3000"
            Write-Info "📊 Logs: .\scripts\deploy-windows.ps1 logs"
            Write-Warning "⚠️  Ensure production backend APIs are accessible!"
        }
        
        "build" {
            if (-not $SkipChecks) { Test-Prerequisites }
            Build-FrontendImages -Environment "dev"
            Build-FrontendImages -Environment "prod"
            Write-Success "Frontend images built successfully!"
        }
        
        "clean" {
            Clear-FrontendResources
        }
        
        "logs" {
            Show-FrontendLogs
        }
        
        "status" {
            Show-FrontendStatus
        }
        
        "help" {
            Show-Help
        }
        
        default {
            Write-Error "Invalid action: $Action"
            Show-Help
            exit 1
        }
    }
}

# Execute main function
try {
    Main
} catch {
    Write-Error "Deployment failed: $_"
    Write-Info "For help: .\scripts\deploy-windows.ps1 help"
    exit 1
}
