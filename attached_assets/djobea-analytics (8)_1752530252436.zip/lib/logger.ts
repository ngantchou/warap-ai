"use client"

interface LogLevel {
  ERROR: 0
  WARN: 1
  INFO: 2
  DEBUG: 3
}

const LOG_LEVELS: LogLevel = {
  ERROR: 0,
  WARN: 1,
  INFO: 2,
  DEBUG: 3,
}

class Logger {
  private level: number

  constructor() {
    this.level = process.env.NODE_ENV === "development" ? LOG_LEVELS.DEBUG : LOG_LEVELS.INFO
  }

  private log(level: keyof LogLevel, message: string, data?: any) {
    if (LOG_LEVELS[level] <= this.level) {
      const timestamp = new Date().toISOString()
      const logData = data ? { message, data, timestamp } : { message, timestamp }

      switch (level) {
        case "ERROR":
          console.error(`[${timestamp}] ERROR:`, message, data)
          break
        case "WARN":
          console.warn(`[${timestamp}] WARN:`, message, data)
          break
        case "INFO":
          console.info(`[${timestamp}] INFO:`, message, data)
          break
        case "DEBUG":
          console.debug(`[${timestamp}] DEBUG:`, message, data)
          break
      }
    }
  }

  error(message: string, data?: any) {
    this.log("ERROR", message, data)
  }

  warn(message: string, data?: any) {
    this.log("WARN", message, data)
  }

  info(message: string, data?: any) {
    this.log("INFO", message, data)
  }

  debug(message: string, data?: any) {
    this.log("DEBUG", message, data)
  }

  logUserAction(action: string, data?: any) {
    this.info(`User action: ${action}`, data)
  }
}

export const logger = new Logger()
