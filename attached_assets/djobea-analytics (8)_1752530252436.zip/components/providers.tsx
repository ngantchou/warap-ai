"use client"

import type React from "react"

import { AuthProvider } from "./auth-provider"
import { NotificationProvider } from "./notification-provider"
import { KeyboardNavigationProvider } from "./keyboard/keyboard-navigation-provider"
import { WebSocketProvider } from "./realtime/websocket-provider"
import { ThemeProvider } from "./theme-provider"
import { ErrorBoundary } from "./error-boundary"
import { Toaster } from "./ui/toaster"

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ErrorBoundary>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
        <AuthProvider>
          <NotificationProvider>
            <WebSocketProvider>
              <KeyboardNavigationProvider>
                {children}
                <Toaster />
              </KeyboardNavigationProvider>
            </WebSocketProvider>
          </NotificationProvider>
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  )
}
