"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface WebSocketContextType {
  isConnected: boolean
  connectionStatus: "connecting" | "connected" | "disconnected" | "error"
  lastMessage: any
  sendMessage: (message: any) => void
}

const WebSocketContext = createContext<WebSocketContextType | undefined>(undefined)

export function WebSocketProvider({ children }: { children: ReactNode }) {
  const [isConnected, setIsConnected] = useState(false)
  const [connectionStatus, setConnectionStatus] = useState<"connecting" | "connected" | "disconnected" | "error">(
    "disconnected",
  )
  const [lastMessage, setLastMessage] = useState<any>(null)

  useEffect(() => {
    // Simulate WebSocket connection
    setConnectionStatus("connecting")

    const timer = setTimeout(() => {
      setIsConnected(true)
      setConnectionStatus("connected")
      console.log("WebSocket connected (simulated)")
    }, 1000)

    // Simulate periodic messages
    const messageInterval = setInterval(() => {
      if (isConnected) {
        setLastMessage({
          type: "update",
          data: { timestamp: new Date().toISOString() },
        })
      }
    }, 30000) // Every 30 seconds

    return () => {
      clearTimeout(timer)
      clearInterval(messageInterval)
    }
  }, [isConnected])

  const sendMessage = (message: any) => {
    if (isConnected) {
      console.log("Sending message:", message)
      // Simulate message sending
    }
  }

  return (
    <WebSocketContext.Provider
      value={{
        isConnected,
        connectionStatus,
        lastMessage,
        sendMessage,
      }}
    >
      {children}
    </WebSocketContext.Provider>
  )
}

export function useWebSocket() {
  const context = useContext(WebSocketContext)
  if (context === undefined) {
    throw new Error("useWebSocket must be used within a WebSocketProvider")
  }
  return context
}
