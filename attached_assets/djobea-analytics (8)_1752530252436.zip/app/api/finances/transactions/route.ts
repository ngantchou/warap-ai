import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function POST(request: NextRequest) {
  try {
    const transactionData = await request.json()

    // Validate required fields
    const requiredFields = ["type", "amount", "category", "description", "paymentMethod", "date"]
    for (const field of requiredFields) {
      if (!transactionData[field]) {
        return NextResponse.json({ error: `Le champ ${field} est requis` }, { status: 400 })
      }
    }

    // Generate transaction ID and reference
    const transactionId = `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    const reference = `REF-${Date.now().toString().slice(-6)}`

    const newTransaction = {
      id: transactionId,
      reference,
      ...transactionData,
      status: "completed",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    // In a real implementation, save to database
    console.log("Nouvelle transaction:", newTransaction)

    return NextResponse.json({
      success: true,
      transaction: newTransaction,
      message: "Transaction ajoutée avec succès",
    })
  } catch (error) {
    console.error("Erreur ajout transaction:", error)
    return NextResponse.json({ error: "Erreur lors de l'ajout de la transaction" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const params = {
      page: Number.parseInt(searchParams.get("page") || "1"),
      limit: Number.parseInt(searchParams.get("limit") || "10"),
      dateRange: searchParams.get("dateRange") || "",
      category: searchParams.get("category") || "",
      type: searchParams.get("type") || "",
      status: searchParams.get("status") || "",
    }

    const response = await apiClient.getTransactions(params)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Transactions API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch transactions data",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
