import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const params = {
      dateRange: searchParams.get("dateRange") || "",
      category: searchParams.get("category") || "",
      type: searchParams.get("type") || "",
      status: searchParams.get("status") || "",
    }

    const response = await apiClient.getFinancesData(params)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Finances API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch finances data",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Simulation d'ajout de transaction
    const newTransaction = {
      id: Date.now().toString(),
      date: new Date().toISOString().split("T")[0],
      ...body,
    }

    return NextResponse.json({
      success: true,
      transaction: newTransaction,
      message: "Transaction ajoutée avec succès",
    })
  } catch (error) {
    console.error("Erreur ajout transaction:", error)
    return NextResponse.json({ error: "Erreur lors de l'ajout de la transaction" }, { status: 500 })
  }
}
