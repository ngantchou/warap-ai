import { NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function POST() {
  try {
    const response = await apiClient.logout()
    return NextResponse.json(response)
  } catch (error) {
    console.error("Logout API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to logout",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
