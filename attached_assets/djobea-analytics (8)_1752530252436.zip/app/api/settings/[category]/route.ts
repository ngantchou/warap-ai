import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function PUT(request: NextRequest, { params }: { params: { category: string } }) {
  try {
    const body = await request.json()
    const response = await apiClient.updateSettings(params.category, body)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Update Settings API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to update settings",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
