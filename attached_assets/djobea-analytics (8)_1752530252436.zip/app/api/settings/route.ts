import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category") || ""

    const response = await apiClient.getSettings(category)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Settings API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch settings",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
