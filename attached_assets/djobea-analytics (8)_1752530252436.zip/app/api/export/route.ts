import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function POST(request: NextRequest) {
  try {
    const { type, format, filters } = await request.json()
    const response = await apiClient.exportData(type, format, filters)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Export API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to export data",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
