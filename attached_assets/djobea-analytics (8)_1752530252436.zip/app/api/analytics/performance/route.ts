import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const period = searchParams.get("period") || "7d"

    const response = await apiClient.getPerformanceData(period)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Performance API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch performance data",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
