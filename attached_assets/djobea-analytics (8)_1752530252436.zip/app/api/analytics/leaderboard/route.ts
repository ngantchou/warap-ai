import { NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function GET() {
  try {
    const response = await apiClient.getLeaderboard()
    return NextResponse.json(response)
  } catch (error) {
    console.error("Leaderboard API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch leaderboard data",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
