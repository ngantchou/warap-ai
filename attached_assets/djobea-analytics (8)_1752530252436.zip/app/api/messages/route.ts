import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

// Mock data
const mockContacts = [
  {
    id: "1",
    name: "Marie Dubois",
    avatar: "/placeholder.svg?height=40&width=40&text=MD",
    role: "client",
    status: "online",
    lastMessage: "Merci pour votre aide, le problème est résolu !",
    lastMessageTime: "Il y a 2 min",
    unreadCount: 0,
    isPinned: true,
    isMuted: false,
    phone: "+237 6 12 34 56 78",
    email: "marie.dubois@email.com",
    location: {
      lat: 4.0511,
      lng: 9.7679,
      address: "Douala, Cameroun",
    },
  },
  {
    id: "2",
    name: "Jean Plombier",
    avatar: "/placeholder.svg?height=40&width=40&text=JP",
    role: "provider",
    status: "online",
    lastMessage: "Je peux venir demain matin vers 9h",
    lastMessageTime: "Il y a 5 min",
    unreadCount: 2,
    isPinned: false,
    isMuted: false,
    phone: "+237 6 98 76 54 32",
    email: "jean.plombier@email.com",
  },
  {
    id: "3",
    name: "Sophie Martin",
    avatar: "/placeholder.svg?height=40&width=40&text=SM",
    role: "client",
    status: "away",
    lastMessage: "D'accord, à bientôt",
    lastMessageTime: "Il y a 1h",
    unreadCount: 1,
    isPinned: false,
    isMuted: false,
    phone: "+237 6 11 22 33 44",
    email: "sophie.martin@email.com",
  },
]

const mockMessages: Record<string, any[]> = {
  "1": [
    {
      id: "1",
      conversationId: "1",
      senderId: "1",
      senderName: "Marie Dubois",
      senderType: "user",
      content: "Bonjour, j'ai un problème avec ma plomberie",
      timestamp: "2024-01-15T10:30:00Z",
      type: "text",
      status: "read",
      attachments: [],
    },
    {
      id: "2",
      conversationId: "1",
      senderId: "ai_agent_1",
      senderName: "Assistant IA Djobea",
      senderType: "ai_agent",
      content:
        "Bonjour Marie ! Je comprends votre problème de plomberie. Pouvez-vous me décrire plus précisément le problème ?",
      timestamp: "2024-01-15T10:31:00Z",
      type: "text",
      status: "read",
      attachments: [],
      metadata: {
        agentId: "ai_agent_1",
        confidence: 0.95,
        processingTime: 1.2,
      },
    },
    {
      id: "3",
      conversationId: "1",
      senderId: "1",
      senderName: "Marie Dubois",
      senderType: "user",
      content: "Voici une photo du problème",
      timestamp: "2024-01-15T10:35:00Z",
      type: "image",
      status: "read",
      attachments: [
        {
          type: "image",
          url: "/placeholder.svg?height=200&width=300&text=Problème+Plomberie",
          name: "probleme_plomberie.jpg",
          size: "2.5 MB",
          thumbnail: "/placeholder.svg?height=100&width=150&text=Thumb",
        },
      ],
    },
    {
      id: "4",
      conversationId: "1",
      senderId: "human_agent_1",
      senderName: "Agent Paul",
      senderType: "human_agent",
      content:
        "Je vois le problème sur la photo. Je vais vous mettre en contact avec Jean, notre meilleur plombier de votre secteur.",
      timestamp: "2024-01-15T10:40:00Z",
      type: "text",
      status: "read",
      attachments: [],
    },
  ],
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const params = {
      type: searchParams.get("type") || "",
      search: searchParams.get("search") || "",
      role: searchParams.get("role") || "",
      status: searchParams.get("status") || "",
      conversationId: searchParams.get("conversationId") || "",
      page: Number.parseInt(searchParams.get("page") || "1"),
      limit: Number.parseInt(searchParams.get("limit") || "10"),
    }

    const response = await apiClient.getMessages(params)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Messages API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch messages data",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const response = await apiClient.sendMessage(body)
    return NextResponse.json(response, { status: 201 })
  } catch (error) {
    console.error("Send Message API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to send message",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const response = await apiClient.updateMessage(body.messageId, body)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Update Message API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to update message",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const messageId = searchParams.get("messageId")

    if (!messageId) {
      return NextResponse.json(
        {
          success: false,
          error: "Message ID is required",
        },
        { status: 400 },
      )
    }

    const response = await apiClient.deleteMessage(messageId)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Delete Message API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to delete message",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
