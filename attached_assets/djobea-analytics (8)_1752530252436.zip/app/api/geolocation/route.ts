import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const bounds = {
      north: Number.parseFloat(searchParams.get("north") || "0"),
      south: Number.parseFloat(searchParams.get("south") || "0"),
      east: Number.parseFloat(searchParams.get("east") || "0"),
      west: Number.parseFloat(searchParams.get("west") || "0"),
    }

    const response = await apiClient.getGeolocationData(bounds)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Geolocation API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch geolocation data",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
