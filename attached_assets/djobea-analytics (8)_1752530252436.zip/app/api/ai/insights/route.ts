import { NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function GET() {
  try {
    const response = await apiClient.getAIInsights()
    return NextResponse.json(response)
  } catch (error) {
    console.error("AI Insights API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch AI insights",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
