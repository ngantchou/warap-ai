import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

// Mock requests database
const mockRequests = [
  {
    id: "REQ-001",
    clientName: "Marie Dubois",
    clientPhone: "+237 6 12 34 56 78",
    clientEmail: "marie.dubois@email.com",
    serviceType: "Électricité",
    description: "Réparation d'une prise électrique défectueuse dans la cuisine",
    location: "Bonamoussadi Centre",
    address: "123 Rue de la Paix, Bonamoussadi",
    priority: "high",
    status: "pending",
    createdAt: "2024-01-15T10:30:00Z",
    updatedAt: "2024-01-15T10:30:00Z",
    scheduledDate: "2024-01-16T14:00:00Z",
    urgency: true,
    estimatedCost: 15000,
    images: ["/placeholder.svg?height=200&width=300"],
    notes: "Client disponible après 14h",
  },
  {
    id: "REQ-002",
    clientName: "Jean Kono",
    clientPhone: "+237 6 98 76 54 32",
    clientEmail: "jean.kono@email.com",
    serviceType: "Plomberie",
    description: "Fuite d'eau sous l'évier de la salle de bain",
    location: "Bonamoussadi Nord",
    address: "456 Avenue des Palmiers, Bonamoussadi",
    priority: "urgent",
    status: "assigned",
    createdAt: "2024-01-14T08:15:00Z",
    updatedAt: "2024-01-14T09:30:00Z",
    scheduledDate: "2024-01-15T09:00:00Z",
    assignedProvider: {
      id: "PROV-003",
      name: "Paul Plomberie",
      rating: 4.6,
    },
    urgency: true,
    estimatedCost: 25000,
    images: ["/placeholder.svg?height=200&width=300"],
  },
  {
    id: "REQ-003",
    clientName: "Fatou Ngo",
    clientPhone: "+237 6 11 22 33 44",
    clientEmail: "fatou.ngo@email.com",
    serviceType: "Ménage",
    description: "Grand ménage de printemps pour un appartement 3 pièces",
    location: "Bonamoussadi Sud",
    address: "789 Boulevard du Soleil, Bonamoussadi",
    priority: "normal",
    status: "in-progress",
    createdAt: "2024-01-13T16:45:00Z",
    updatedAt: "2024-01-15T08:00:00Z",
    scheduledDate: "2024-01-15T08:00:00Z",
    assignedProvider: {
      id: "PROV-004",
      name: "Alain Maintenance",
      rating: 4.5,
    },
    urgency: false,
    estimatedCost: 20000,
  },
  {
    id: "REQ-004",
    clientName: "Paul Ateba",
    clientPhone: "+237 6 55 66 77 88",
    clientEmail: "paul.ateba@email.com",
    serviceType: "Jardinage",
    description: "Taille des haies et entretien du jardin",
    location: "Bonamoussadi Est",
    address: "321 Rue des Fleurs, Bonamoussadi",
    priority: "low",
    status: "completed",
    createdAt: "2024-01-10T14:20:00Z",
    updatedAt: "2024-01-12T17:30:00Z",
    scheduledDate: "2024-01-12T08:00:00Z",
    completedDate: "2024-01-12T17:30:00Z",
    assignedProvider: {
      id: "PROV-004",
      name: "Alain Maintenance",
      rating: 4.5,
    },
    urgency: false,
    estimatedCost: 18000,
    finalCost: 18000,
    rating: 5,
    feedback: "Excellent travail, très professionnel et ponctuel",
  },
  {
    id: "REQ-005",
    clientName: "Sophie Biya",
    clientPhone: "+237 6 99 88 77 66",
    clientEmail: "sophie.biya@email.com",
    serviceType: "Électroménager",
    description: "Réparation d'un réfrigérateur qui ne refroidit plus",
    location: "Bonamoussadi Centre",
    address: "654 Place du Marché, Bonamoussadi",
    priority: "high",
    status: "cancelled",
    createdAt: "2024-01-08T11:10:00Z",
    updatedAt: "2024-01-09T10:00:00Z",
    urgency: false,
    estimatedCost: 30000,
    notes: "Client a annulé - a acheté un nouveau réfrigérateur",
  },
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const params = {
      page: Number.parseInt(searchParams.get("page") || "1"),
      limit: Number.parseInt(searchParams.get("limit") || "10"),
      search: searchParams.get("search") || "",
      serviceType: searchParams.get("serviceType") || "",
      location: searchParams.get("location") || "",
      priority: searchParams.get("priority") || "",
      status: searchParams.get("status") || "",
      dateRange: searchParams.get("dateRange") || "",
    }

    const response = await apiClient.getRequests(params)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Requests API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch requests data",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const response = await apiClient.createRequest(body)
    return NextResponse.json(response, { status: 201 })
  } catch (error) {
    console.error("Create Request API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to create request",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
