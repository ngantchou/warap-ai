import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { providerId } = await request.json()
    const response = await apiClient.assignRequest(params.id, providerId)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Assign Request API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to assign request",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
