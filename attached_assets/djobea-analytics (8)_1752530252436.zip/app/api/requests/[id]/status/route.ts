import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { status } = await request.json()
    const response = await apiClient.updateRequestStatus(params.id, status)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Update Request Status API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to update request status",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
