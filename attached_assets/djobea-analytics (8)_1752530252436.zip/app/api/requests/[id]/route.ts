import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const response = await apiClient.getRequest(params.id)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Get Request API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch request",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const response = await apiClient.updateRequest(params.id, body)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Update Request API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to update request",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
