import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { reason } = await request.json()
    const response = await apiClient.cancelRequest(params.id, reason)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Cancel Request API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to cancel request",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
