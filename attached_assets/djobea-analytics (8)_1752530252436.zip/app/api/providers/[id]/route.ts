import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const response = await apiClient.getProvider(params.id)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Get Provider API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch provider",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const response = await apiClient.updateProvider(params.id, body)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Update Provider API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to update provider",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const response = await apiClient.deleteProvider(params.id)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Delete Provider API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to delete provider",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
