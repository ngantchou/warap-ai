import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { status } = await request.json()
    const response = await apiClient.updateProviderStatus(params.id, status)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Update Provider Status API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to update provider status",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
