import { NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function PUT() {
  try {
    const response = await apiClient.markAllNotificationsAsRead()
    return NextResponse.json(response)
  } catch (error) {
    console.error("Mark All Notifications Read API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to mark all notifications as read",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
