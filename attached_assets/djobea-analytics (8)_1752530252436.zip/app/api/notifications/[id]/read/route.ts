import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const response = await apiClient.markNotificationAsRead(params.id)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Mark Notification Read API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to mark notification as read",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
