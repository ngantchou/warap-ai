import { type NextRequest, NextResponse } from "next/server"
import { apiClient } from "@/lib/api-client"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const params = {
      page: Number.parseInt(searchParams.get("page") || "1"),
      limit: Number.parseInt(searchParams.get("limit") || "10"),
      read: searchParams.get("read") === "true",
      type: searchParams.get("type") || "",
    }

    const response = await apiClient.getNotifications(params)
    return NextResponse.json(response)
  } catch (error) {
    console.error("Notifications API Error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch notifications",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
